import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { study as studyApi, decks as decksApi } from '../api/client';
import { Flashcard } from '../components/Flashcard';
import type { Card } from '../types';

export function Study() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [deckTitle, setDeckTitle] = useState('');
  const [cards, setCards] = useState<Card[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isComplete, setIsComplete] = useState(false);
  const [results, setResults] = useState<{ correct: number; total: number }>({ correct: 0, total: 0 });
  const startTimeRef = useRef<number>(Date.now());

  useEffect(() => {
    const load = async () => {
      if (!id) return;
      try {
        const [deckRes, studyRes] = await Promise.all([
          decksApi.get(id),
          studyApi.getDueCards(id),
        ]);
        setDeckTitle(deckRes.deck.title);
        setCards(studyRes.cards);
        startTimeRef.current = Date.now();
      } catch {
        navigate('/dashboard');
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [id]);

  const handleReview = useCallback(async (quality: number) => {
    if (!id) return;

    const currentCard = cards[currentIndex];
    if (!currentCard) return;

    try {
      await studyApi.submitReviews([{ cardId: currentCard.id, quality }]);
    } catch (err) {
      console.error('Failed to submit review:', err);
    }

    setResults(prev => ({
      correct: prev.correct + (quality >= 3 ? 1 : 0),
      total: prev.total + 1,
    }));

    if (currentIndex < cards.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      const duration = Math.round((Date.now() - startTimeRef.current) / 1000);
      try {
        await studyApi.completeSession({
          deckId: id,
          cardsStudied: cards.length,
          cardsCorrect: results.correct + (quality >= 3 ? 1 : 0),
          durationSeconds: duration,
        });
      } catch (err) {
        console.error('Failed to complete session:', err);
      }
      setIsComplete(true);
    }
  }, [id, cards, currentIndex, results.correct]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (isComplete) {
    const accuracy = results.total > 0 ? Math.round((results.correct / results.total) * 100) : 0;
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 mx-auto mb-6 bg-green-50 dark:bg-green-500/10 rounded-full flex items-center justify-center">
            <svg className="w-10 h-10 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Session Complete!</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-8">
            You studied {results.total} cards with {accuracy}% accuracy.
          </p>
          <div className="flex items-center justify-center gap-4">
            <Link
              to={`/study/${id}`}
              className="px-6 py-2.5 bg-primary-500 hover:bg-primary-600 text-white font-semibold rounded-xl transition-all"
            >
              Study Again
            </Link>
            <Link
              to={`/deck/${id}`}
              className="px-6 py-2.5 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 font-medium rounded-xl transition-all"
            >
              Back to Deck
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (cards.length === 0) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 dark:bg-gray-800 rounded-2xl flex items-center justify-center">
            <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">All caught up!</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-6">No cards due for review in "{deckTitle}".</p>
          <Link
            to={`/deck/${id}`}
            className="px-6 py-2.5 bg-primary-500 hover:bg-primary-600 text-white font-semibold rounded-xl transition-all"
          >
            Back to Deck
          </Link>
        </div>
      </div>
    );
  }

  const currentCard = cards[currentIndex];
  const progress = ((currentIndex) / cards.length) * 100;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <Link
          to={`/deck/${id}`}
          className="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 mb-4 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
          </svg>
          {deckTitle}
        </Link>

        <div className="flex items-center justify-between mb-3">
          <h1 className="text-lg font-semibold text-gray-900 dark:text-white">Study Session</h1>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {currentIndex + 1} of {cards.length}
          </span>
        </div>

        <div className="w-full bg-gray-200 dark:bg-gray-800 rounded-full h-1.5 overflow-hidden">
          <div
            className="bg-primary-500 h-full rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <Flashcard
        key={currentCard.id}
        card={currentCard}
        onReview={handleReview}
      />
    </div>
  );
}
