const API_BASE = '/api';

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem('token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new ApiError(response.status, error.error || 'Request failed');
  }

  return response.json();
}

export const auth = {
  register: (data: { email: string; username: string; password: string }) =>
    request<{ token: string; user: { id: string; email: string; username: string } }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  login: (data: { email: string; password: string }) =>
    request<{ token: string; user: { id: string; email: string; username: string } }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};

export const decks = {
  list: () => request<{ decks: import('../types').Deck[] }>('/decks'),

  get: (id: string) => request<{ deck: import('../types').Deck }>(`/decks/${id}`),

  create: (data: { title: string; description?: string; color?: string }) =>
    request<{ deck: import('../types').Deck }>('/decks', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  update: (id: string, data: Partial<{ title: string; description: string; color: string }>) =>
    request<{ deck: import('../types').Deck }>(`/decks/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    request<{ message: string }>(`/decks/${id}`, {
      method: 'DELETE',
    }),
};

export const cards = {
  list: (deckId: string) => request<{ cards: import('../types').Card[] }>(`/cards/deck/${deckId}`),

  create: (deckId: string, data: { front: string; back: string; hint?: string }) =>
    request<{ card: import('../types').Card }>(`/cards/deck/${deckId}`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  update: (id: string, data: Partial<{ front: string; back: string; hint: string }>) =>
    request<{ card: import('../types').Card }>(`/cards/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    request<{ message: string }>(`/cards/${id}`, {
      method: 'DELETE',
    }),
};

export const study = {
  getDueCards: (deckId: string) =>
    request<{ cards: import('../types').Card[]; total: number }>(`/study/due/${deckId}`),

  getStats: (deckId: string) =>
    request<import('../types').DeckStats>(`/study/stats/${deckId}`),

  submitReviews: (reviews: { cardId: string; quality: number }[]) =>
    request<{ results: import('../types').ReviewResult[] }>('/study/review', {
      method: 'POST',
      body: JSON.stringify({ reviews }),
    }),

  startSession: (deckId: string) =>
    request<{ sessionId: string; startTime: string }>('/study/session/start', {
      method: 'POST',
      body: JSON.stringify({ deckId }),
    }),

  completeSession: (data: { deckId: string; cardsStudied: number; cardsCorrect: number; durationSeconds: number }) =>
    request<{ sessionId: string }>('/study/session/complete', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getHistory: (deckId: string) =>
    request<{ sessions: import('../types').StudySession[] }>(`/study/history/${deckId}`),
};
