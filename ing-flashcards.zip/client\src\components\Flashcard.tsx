import { useState, useCallback } from 'react';
import type { Card } from '../types';

interface FlashcardProps {
  card: Card;
  onReview: (quality: number) => void;
}

export function Flashcard({ card, onReview }: FlashcardProps) {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleFlip = useCallback(() => {
    if (isAnimating) return;
    setIsAnimating(true);
    setIsFlipped(prev => !prev);
    setTimeout(() => setIsAnimating(false), 400);
  }, [isAnimating]);

  const handleReview = useCallback((quality: number) => {
    setIsFlipped(false);
    onReview(quality);
  }, [onReview]);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        className="relative cursor-pointer select-none"
        onClick={handleFlip}
        style={{ minHeight: '320px' }}
      >
        <div
          className={`absolute inset-0 transition-all duration-500 [transform-style:preserve-3d] ${
            isFlipped ? '[transform:rotateY(180deg)]' : ''
          }`}
        >
          {/* Front */}
          <div
            className={`absolute inset-0 backface-hidden bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-lg shadow-gray-200/50 dark:shadow-black/20 p-8 flex flex-col items-center justify-center ${
              isFlipped ? 'invisible' : ''
            }`}
          >
            <p className="text-2xl text-center text-gray-900 dark:text-white leading-relaxed">
              {card.front}
            </p>
            <p className="mt-6 text-sm text-gray-400 dark:text-gray-500">
              Tap to reveal answer
            </p>
          </div>

          {/* Back */}
          <div
            className={`absolute inset-0 backface-hidden [transform:rotateY(180deg)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-lg shadow-gray-200/50 dark:shadow-black/20 p-8 flex flex-col items-center justify-center ${
              !isFlipped ? 'invisible' : ''
            }`}
          >
            <p className="text-2xl text-center text-gray-900 dark:text-white leading-relaxed">
              {card.back}
            </p>
            {card.hint && (
              <p className="mt-4 text-sm text-gray-400 dark:text-gray-500 italic">
                💡 {card.hint}
              </p>
            )}
          </div>
        </div>
      </div>

      {isFlipped && (
        <div className="mt-6 animate-scale-in">
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400 text-center mb-3">
            How well did you know this?
          </p>
          <div className="flex items-center justify-center gap-2">
            {[
              { label: 'Again', quality: 0, color: 'red' },
              { label: 'Hard', quality: 2, color: 'orange' },
              { label: 'Good', quality: 3, color: 'primary' },
              { label: 'Easy', quality: 5, color: 'green' },
            ].map(({ label, quality, color }) => (
              <button
                key={quality}
                onClick={(e) => {
                  e.stopPropagation();
                  handleReview(quality);
                }}
                className={`
                  px-5 py-2.5 rounded-xl font-medium text-sm transition-all duration-150
                  ${color === 'red' ? 'bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-500/20' : ''}
                  ${color === 'orange' ? 'bg-orange-50 dark:bg-orange-500/10 text-orange-600 dark:text-orange-400 hover:bg-orange-100 dark:hover:bg-orange-500/20' : ''}
                  ${color === 'primary' ? 'bg-primary-50 dark:bg-primary-500/10 text-primary-600 dark:text-primary-400 hover:bg-primary-100 dark:hover:bg-primary-500/20' : ''}
                  ${color === 'green' ? 'bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-500/20' : ''}
                  active:scale-95
                `}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
