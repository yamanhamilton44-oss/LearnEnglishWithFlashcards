import { z } from 'zod';

export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  username: z.string().min(3, 'Username must be at least 3 characters').max(30, 'Username must be at most 30 characters'),
  password: z.string().min(6, 'Password must be at least 6 characters').max(100),
});

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

export const deckSchema = z.object({
  title: z.string().min(1, 'Title is required').max(200),
  description: z.string().max(1000).default(''),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Invalid color hex').default('#6366f1'),
});

export const cardSchema = z.object({
  front: z.string().min(1, 'Front text is required').max(2000),
  back: z.string().min(1, 'Back text is required').max(2000),
  hint: z.string().max(500).default(''),
});

export const reviewSchema = z.object({
  cardId: z.string().uuid(),
  quality: z.number().int().min(0).max(5),
});

export const reviewBatchSchema = z.object({
  reviews: z.array(reviewSchema).min(1).max(100),
});
