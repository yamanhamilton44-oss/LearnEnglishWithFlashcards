# ING Flashcards

A modern, professional flashcard web application for language learning with spaced repetition.

## Features

- **SM-2 Spaced Repetition** - Scientifically-proven algorithm for optimal review timing
- **Beautiful UI** - Clean, minimal design with dark mode support
- **Study Modes** - Card flip with self-assessment (Again, Hard, Good, Easy)
- **Progress Tracking** - Detailed statistics for each deck
- **Responsive** - Works perfectly on desktop and mobile

## Tech Stack

- **Frontend**: React, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript
- **Database**: SQLite (via better-sqlite3)
- **Auth**: JWT with bcrypt password hashing

## Getting Started

### Prerequisites

- Node.js 18+
- npm 9+

### Installation

```bash
# Clone the repository
git clone https://github.com/anomalyco/ing-flashcards.git
cd ing-flashcards

# Install all dependencies
npm install
npm install --prefix client
npm install --prefix server

# Start development servers
npm run dev
```

The client runs on `http://localhost:5173` and the server on `http://localhost:3001`.

### Production Build

```bash
npm run build
```

To serve the production build, use the server's static file serving or a reverse proxy.

## Project Structure

```
ing-flashcards/
├── client/                 # React frontend
│   ├── src/
│   │   ├── api/           # API client
│   │   ├── components/    # Reusable components
│   │   ├── context/       # React contexts
│   │   ├── pages/         # Page components
│   │   └── types/         # TypeScript types
│   └── ...
├── server/                 # Express backend
│   ├── src/
│   │   ├── routes/        # API routes
│   │   ├── middleware/     # Auth middleware
│   │   ├── utils/         # SM-2 algorithm, validation
│   │   └── database.ts    # SQLite setup
│   └── ...
└── package.json           # Root workspace
```

## API Endpoints

### Auth
- `POST /api/auth/register` - Create account
- `POST /api/auth/login` - Sign in

### Decks
- `GET /api/decks` - List user's decks
- `POST /api/decks` - Create deck
- `GET /api/decks/:id` - Get deck details
- `PUT /api/decks/:id` - Update deck
- `DELETE /api/decks/:id` - Delete deck

### Cards
- `GET /api/cards/deck/:deckId` - List cards in deck
- `POST /api/cards/deck/:deckId` - Add card
- `PUT /api/cards/:id` - Update card
- `DELETE /api/cards/:id` - Delete card

### Study
- `GET /api/study/due/:deckId` - Get due cards
- `GET /api/study/stats/:deckId` - Get deck statistics
- `POST /api/study/review` - Submit card reviews
- `POST /api/study/session/start` - Start study session
- `POST /api/study/session/complete` - Complete study session
- `GET /api/study/history/:deckId` - Get study history

## License

MIT
