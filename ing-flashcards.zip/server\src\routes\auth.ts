import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { generateToken } from '../middleware/auth';
import { registerSchema, loginSchema } from '../utils/validation';
import { queryOne, execute } from '../utils/db';

const router = Router();

router.post('/register', async (req: Request, res: Response) => {
  try {
    const data = registerSchema.parse(req.body);

    const existingUser = await queryOne('SELECT id FROM users WHERE email = ? OR username = ?', [data.email, data.username]);
    if (existingUser) {
      res.status(409).json({ error: 'Email or username already exists' });
      return;
    }

    const salt = bcrypt.genSaltSync(12);
    const passwordHash = bcrypt.hashSync(data.password, salt);

    const id = uuidv4();
    const now = new Date().toISOString();

    await execute(
      'INSERT INTO users (id, email, username, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      [id, data.email, data.username, passwordHash, now, now]
    );

    const token = generateToken({ userId: id, email: data.email, username: data.username });

    res.status(201).json({
      token,
      user: { id, email: data.email, username: data.username },
    });
  } catch (error: any) {
    if (error.name === 'ZodError') {
      res.status(400).json({ error: error.errors[0].message });
      return;
    }
    console.error('Register error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/login', async (req: Request, res: Response) => {
  try {
    const data = loginSchema.parse(req.body);

    const user = await queryOne('SELECT * FROM users WHERE email = ?', [data.email]);
    if (!user) {
      res.status(401).json({ error: 'Invalid email or password' });
      return;
    }

    const validPassword = bcrypt.compareSync(data.password, user.password_hash as string);
    if (!validPassword) {
      res.status(401).json({ error: 'Invalid email or password' });
      return;
    }

    const token = generateToken({ userId: user.id as string, email: user.email as string, username: user.username as string });

    res.json({
      token,
      user: { id: user.id, email: user.email, username: user.username },
    });
  } catch (error: any) {
    if (error.name === 'ZodError') {
      res.status(400).json({ error: error.errors[0].message });
      return;
    }
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
