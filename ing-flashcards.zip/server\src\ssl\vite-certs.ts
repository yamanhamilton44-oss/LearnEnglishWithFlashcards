import fs from 'fs';
import path from 'path';
import { generate } from 'selfsigned';

const CERT_DIR = path.join(__dirname, '..', '..', 'certs');
const KEY_FILE = path.join(CERT_DIR, 'vite.key');
const CERT_FILE = path.join(CERT_DIR, 'vite.crt');

export async function getViteHttpsOptions(): Promise<{ key: string; cert: string } | null> {
  if (fs.existsSync(KEY_FILE) && fs.existsSync(CERT_FILE)) {
    return {
      key: fs.readFileSync(KEY_FILE, 'utf-8'),
      cert: fs.readFileSync(CERT_FILE, 'utf-8'),
    };
  }

  if (!fs.existsSync(CERT_DIR)) {
    fs.mkdirSync(CERT_DIR, { recursive: true });
  }

  const now = new Date();
  const expiry = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);

  const attrs = [{ name: 'commonName', value: 'localhost' }];
  const pems = await generate(attrs, {
    keySize: 2048,
    algorithm: 'sha256',
    notBeforeDate: now,
    notAfterDate: expiry,
    extensions: [
      {
        name: 'subjectAltName',
        altNames: [
          { type: 2, value: 'localhost' },
          { type: 7, ip: '127.0.0.1' },
        ],
      },
    ],
  });

  fs.writeFileSync(KEY_FILE, pems.private);
  fs.writeFileSync(CERT_FILE, pems.cert);

  return { key: pems.private, cert: pems.cert };
}
