import { useState, type FormEvent } from 'react';
import { cards as cardsApi } from '../api/client';

interface AddCardModalProps {
  deckId: string;
  onClose: () => void;
  onCreated: () => void;
}

export function AddCardModal({ deckId, onClose, onCreated }: AddCardModalProps) {
  const [front, setFront] = useState('');
  const [back, setBack] = useState('');
  const [hint, setHint] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!front.trim() || !back.trim()) return;

    setIsLoading(true);
    setError('');

    try {
      await cardsApi.create(deckId, {
        front: front.trim(),
        back: back.trim(),
        hint: hint.trim(),
      });
      setFront('');
      setBack('');
      setHint('');
      onCreated();
    } catch (err: any) {
      setError(err.message || 'Failed to create card');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in" onClick={onClose}>
      <div className="w-full max-w-lg bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-2xl p-6 animate-scale-in" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Add Card</h2>
          <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-800 rounded-xl text-sm text-red-600 dark:text-red-400">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="card-front" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Front (question)
            </label>
            <textarea
              id="card-front"
              value={front}
              onChange={e => setFront(e.target.value)}
              placeholder="e.g., What does 'ephemeral' mean?"
              required
              maxLength={2000}
              rows={3}
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all resize-none"
              autoFocus
            />
          </div>

          <div>
            <label htmlFor="card-back" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Back (answer)
            </label>
            <textarea
              id="card-back"
              value={back}
              onChange={e => setBack(e.target.value)}
              placeholder="e.g., Lasting for a very short time; fleeting."
              required
              maxLength={2000}
              rows={3}
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all resize-none"
            />
          </div>

          <div>
            <label htmlFor="card-hint" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
              Hint <span className="text-gray-400">(optional)</span>
            </label>
            <input
              id="card-hint"
              type="text"
              value={hint}
              onChange={e => setHint(e.target.value)}
              placeholder="A small clue..."
              maxLength={500}
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 font-medium rounded-xl transition-all"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={isLoading || !front.trim() || !back.trim()}
              className="flex-1 py-2.5 bg-primary-500 hover:bg-primary-600 disabled:bg-primary-400 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-all active:scale-[0.98]"
            >
              {isLoading ? 'Adding...' : 'Add Card'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
