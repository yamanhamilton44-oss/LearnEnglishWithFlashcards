import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { authenticateToken } from '../middleware/auth';
import { reviewBatchSchema } from '../utils/validation';
import { calculateSM2 } from '../utils/sm2';
import { queryAll, queryOne, execute } from '../utils/db';

const router = Router();

router.use(authenticateToken);

router.get('/due/:deckId', async (req: Request, res: Response) => {
  try {
    const deck = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [req.params.deckId, req.user!.userId]
    );

    if (!deck) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    const now = new Date().toISOString();
    const cards = await queryAll(
      `SELECT * FROM cards
       WHERE deck_id = ? AND (next_review IS NULL OR next_review <= ?)
       ORDER BY CASE WHEN next_review IS NULL THEN 0 ELSE 1 END, next_review ASC
       LIMIT 50`,
      [req.params.deckId, now]
    );

    res.json({ cards, total: cards.length });
  } catch (error) {
    console.error('Get due cards error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/stats/:deckId', async (req: Request, res: Response) => {
  try {
    const deck = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [req.params.deckId, req.user!.userId]
    );

    if (!deck) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    const now = new Date().toISOString();

    const totalCards = await queryOne(
      'SELECT COUNT(*) as count FROM cards WHERE deck_id = ?',
      [req.params.deckId]
    );

    const dueCards = await queryOne(
      `SELECT COUNT(*) as count FROM cards
       WHERE deck_id = ? AND (next_review IS NULL OR next_review <= ?)`,
      [req.params.deckId, now]
    );

    const newCards = await queryOne(
      'SELECT COUNT(*) as count FROM cards WHERE deck_id = ? AND repetitions = 0',
      [req.params.deckId]
    );

    const learningCards = await queryOne(
      `SELECT COUNT(*) as count FROM cards
       WHERE deck_id = ? AND repetitions > 0 AND next_review IS NOT NULL AND next_review > ?`,
      [req.params.deckId, now]
    );

    res.json({
      totalCards: totalCards!.count,
      dueCards: dueCards!.count,
      newCards: newCards!.count,
      learningCards: learningCards!.count,
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/review', async (req: Request, res: Response) => {
  try {
    const data = reviewBatchSchema.parse(req.body);
    const results: any[] = [];

    for (const review of data.reviews) {
      const card = await queryOne(
        `SELECT c.* FROM cards c JOIN decks d ON c.deck_id = d.id WHERE c.id = ? AND d.user_id = ?`,
        [review.cardId, req.user!.userId]
      );

      if (!card) continue;

      const sm2Result = calculateSM2(
        review.quality,
        card.ease_factor as number,
        card.interval as number,
        card.repetitions as number
      );

      const now = new Date().toISOString();
      await execute(
        `UPDATE cards SET ease_factor = ?, interval = ?, repetitions = ?, next_review = ?, updated_at = ? WHERE id = ?`,
        [sm2Result.easeFactor, sm2Result.interval, sm2Result.repetitions, sm2Result.nextReview.toISOString(), now, card.id as string]
      );

      results.push({
        cardId: card.id,
        quality: review.quality,
        easeFactor: sm2Result.easeFactor,
        interval: sm2Result.interval,
        repetitions: sm2Result.repetitions,
        nextReview: sm2Result.nextReview.toISOString(),
      });
    }

    res.json({ results });
  } catch (error: any) {
    if (error.name === 'ZodError') {
      res.status(400).json({ error: error.errors[0].message });
      return;
    }
    console.error('Review error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/session/start', async (req: Request, res: Response) => {
  try {
    const { deckId } = req.body;
    if (!deckId) {
      res.status(400).json({ error: 'deckId is required' });
      return;
    }

    const deck = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [deckId, req.user!.userId]
    );

    if (!deck) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    const id = uuidv4();
    res.json({ sessionId: id, startTime: new Date().toISOString() });
  } catch (error) {
    console.error('Start session error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/session/complete', async (req: Request, res: Response) => {
  try {
    const { deckId, cardsStudied, cardsCorrect, durationSeconds } = req.body;

    if (!deckId || cardsStudied === undefined || cardsCorrect === undefined || durationSeconds === undefined) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    const deck = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [deckId, req.user!.userId]
    );

    if (!deck) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    const id = uuidv4();
    const now = new Date().toISOString();

    await execute(
      'INSERT INTO study_sessions (id, user_id, deck_id, cards_studied, cards_correct, duration_seconds, completed_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [id, req.user!.userId, deckId, cardsStudied, cardsCorrect, durationSeconds, now]
    );

    res.status(201).json({ sessionId: id });
  } catch (error) {
    console.error('Complete session error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/history/:deckId', async (req: Request, res: Response) => {
  try {
    const deck = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [req.params.deckId, req.user!.userId]
    );

    if (!deck) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    const sessions = await queryAll(
      `SELECT * FROM study_sessions WHERE deck_id = ? AND user_id = ? ORDER BY completed_at DESC LIMIT 30`,
      [req.params.deckId, req.user!.userId]
    );

    res.json({ sessions });
  } catch (error) {
    console.error('Get history error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
