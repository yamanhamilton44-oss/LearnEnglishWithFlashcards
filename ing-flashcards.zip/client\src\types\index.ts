export interface User {
  id: string;
  email: string;
  username: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface Deck {
  id: string;
  user_id: string;
  title: string;
  description: string;
  color: string;
  card_count: number;
  created_at: string;
  updated_at: string;
}

export interface Card {
  id: string;
  deck_id: string;
  front: string;
  back: string;
  hint: string;
  ease_factor: number;
  interval: number;
  repetitions: number;
  next_review: string | null;
  created_at: string;
  updated_at: string;
}

export interface StudySession {
  id: string;
  user_id: string;
  deck_id: string;
  cards_studied: number;
  cards_correct: number;
  duration_seconds: number;
  completed_at: string;
}

export interface DeckStats {
  totalCards: number;
  dueCards: number;
  newCards: number;
  learningCards: number;
}

export interface ReviewResult {
  cardId: string;
  quality: number;
  easeFactor: number;
  interval: number;
  repetitions: number;
  nextReview: string;
}

export type ReviewQuality = 0 | 1 | 2 | 3 | 4 | 5;
