import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { Layout } from './components/Layout';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { Dashboard } from './pages/Dashboard';
import { DeckDetail } from './pages/DeckDetail';
import { Study } from './pages/Study';

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/deck/:id"
                element={
                  <ProtectedRoute>
                    <DeckDetail />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/study/:id"
                element={
                  <ProtectedRoute>
                    <Study />
                  </ProtectedRoute>
                }
              />
              <Route
                path="*"
                element={
                  <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
                    <div className="text-center">
                      <h1 className="text-6xl font-bold text-gray-300 dark:text-gray-700 mb-4">404</h1>
                      <p className="text-gray-500 dark:text-gray-400 mb-6">Page not found</p>
                      <a href="/" className="text-primary-500 hover:text-primary-600 font-medium">Go home</a>
                    </div>
                  </div>
                }
              />
            </Route>
          </Routes>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
