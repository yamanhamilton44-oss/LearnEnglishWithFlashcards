import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { authenticateToken } from '../middleware/auth';
import { deckSchema } from '../utils/validation';
import { queryAll, queryOne, execute } from '../utils/db';

const router = Router();

router.use(authenticateToken);

router.get('/', async (req: Request, res: Response) => {
  try {
    const decks = await queryAll(
      'SELECT * FROM decks WHERE user_id = ? ORDER BY updated_at DESC',
      [req.user!.userId]
    );
    res.json({ decks });
  } catch (error) {
    console.error('Get decks error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/:id', async (req: Request, res: Response) => {
  try {
    const deck = await queryOne(
      'SELECT * FROM decks WHERE id = ? AND user_id = ?',
      [req.params.id, req.user!.userId]
    );

    if (!deck) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    res.json({ deck });
  } catch (error) {
    console.error('Get deck error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/', async (req: Request, res: Response) => {
  try {
    const data = deckSchema.parse(req.body);
    const id = uuidv4();
    const now = new Date().toISOString();

    await execute(
      'INSERT INTO decks (id, user_id, title, description, color, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [id, req.user!.userId, data.title, data.description, data.color, now, now]
    );

    const deck = await queryOne('SELECT * FROM decks WHERE id = ?', [id]);
    res.status(201).json({ deck });
  } catch (error: any) {
    if (error.name === 'ZodError') {
      res.status(400).json({ error: error.errors[0].message });
      return;
    }
    console.error('Create deck error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.put('/:id', async (req: Request, res: Response) => {
  try {
    const data = deckSchema.partial().parse(req.body);

    const existing = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [req.params.id, req.user!.userId]
    );

    if (!existing) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    const now = new Date().toISOString();
    const updates: string[] = [];
    const values: any[] = [];

    if (data.title !== undefined) { updates.push('title = ?'); values.push(data.title); }
    if (data.description !== undefined) { updates.push('description = ?'); values.push(data.description); }
    if (data.color !== undefined) { updates.push('color = ?'); values.push(data.color); }

    updates.push('updated_at = ?');
    values.push(now);
    values.push(req.params.id);

    await execute(
      `UPDATE decks SET ${updates.join(', ')} WHERE id = ?`,
      values
    );

    const deck = await queryOne('SELECT * FROM decks WHERE id = ?', [req.params.id]);
    res.json({ deck });
  } catch (error: any) {
    if (error.name === 'ZodError') {
      res.status(400).json({ error: error.errors[0].message });
      return;
    }
    console.error('Update deck error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const existing = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [req.params.id, req.user!.userId]
    );

    if (!existing) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    await execute('DELETE FROM decks WHERE id = ?', [req.params.id]);
    res.json({ message: 'Deck deleted successfully' });
  } catch (error) {
    console.error('Delete deck error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
