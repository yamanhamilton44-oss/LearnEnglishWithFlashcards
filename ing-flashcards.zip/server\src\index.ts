import express from 'express';
import cors from 'cors';
import http from 'http';
import https from 'https';
import { getDatabase } from './database';
import { getHttpsOptions } from './ssl/cert';
import authRoutes from './routes/auth';
import deckRoutes from './routes/decks';
import cardRoutes from './routes/cards';
import studyRoutes from './routes/study';

const app = express();
const HTTP_PORT = process.env.HTTP_PORT ? parseInt(process.env.HTTP_PORT) : 3001;
const HTTPS_PORT = process.env.HTTPS_PORT ? parseInt(process.env.HTTPS_PORT) : 3443;

app.use(cors({
  origin: [
    process.env.CORS_ORIGIN || 'https://localhost:5173',
    'https://localhost:5173',
    'http://localhost:5173',
    'https://127.0.0.1:5173',
    'http://127.0.0.1:5173',
  ].filter(Boolean),
  credentials: true,
}));

app.use(express.json({ limit: '10mb' }));

app.use('/api/auth', authRoutes);
app.use('/api/decks', deckRoutes);
app.use('/api/cards', cardRoutes);
app.use('/api/study', studyRoutes);

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use((_req, res) => {
  res.status(404).json({ error: 'Not found' });
});

app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

async function start() {
  try {
    await getDatabase();
    console.log('[db] Database initialized');

    http.createServer(app).listen(HTTP_PORT, () => {
      console.log(`[http] Server running on http://localhost:${HTTP_PORT}`);
    });

    const ssl = await getHttpsOptions();
    if (ssl) {
      https.createServer(ssl, app).listen(HTTPS_PORT, () => {
        console.log(`[https] Server running on https://localhost:${HTTPS_PORT}`);
      });
    }
  } catch (error) {
    console.error('[server] Failed to start:', error);
    process.exit(1);
  }
}

start();

export default app;
