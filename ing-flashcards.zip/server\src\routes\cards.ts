import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { authenticateToken } from '../middleware/auth';
import { cardSchema } from '../utils/validation';
import { queryAll, queryOne, execute } from '../utils/db';

const router = Router();

router.use(authenticateToken);

router.get('/deck/:deckId', async (req: Request, res: Response) => {
  try {
    const deck = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [req.params.deckId, req.user!.userId]
    );

    if (!deck) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    const cards = await queryAll(
      'SELECT * FROM cards WHERE deck_id = ? ORDER BY created_at ASC',
      [req.params.deckId]
    );

    res.json({ cards });
  } catch (error) {
    console.error('Get cards error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/deck/:deckId', async (req: Request, res: Response) => {
  try {
    const data = cardSchema.parse(req.body);

    const deck = await queryOne(
      'SELECT id FROM decks WHERE id = ? AND user_id = ?',
      [req.params.deckId, req.user!.userId]
    );

    if (!deck) {
      res.status(404).json({ error: 'Deck not found' });
      return;
    }

    const id = uuidv4();
    const now = new Date().toISOString();

    await execute(
      `INSERT INTO cards (id, deck_id, front, back, hint, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, req.params.deckId, data.front, data.back, data.hint, now, now]
    );

    const countResult = await queryOne(
      'SELECT COUNT(*) as count FROM cards WHERE deck_id = ?',
      [req.params.deckId]
    );

    await execute(
      'UPDATE decks SET card_count = ?, updated_at = ? WHERE id = ?',
      [countResult!.count, now, req.params.deckId]
    );

    const card = await queryOne('SELECT * FROM cards WHERE id = ?', [id]);
    res.status(201).json({ card });
  } catch (error: any) {
    if (error.name === 'ZodError') {
      res.status(400).json({ error: error.errors[0].message });
      return;
    }
    console.error('Create card error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.put('/:id', async (req: Request, res: Response) => {
  try {
    const data = cardSchema.partial().parse(req.body);

    const card = await queryOne(
      `SELECT c.* FROM cards c JOIN decks d ON c.deck_id = d.id WHERE c.id = ? AND d.user_id = ?`,
      [req.params.id, req.user!.userId]
    );

    if (!card) {
      res.status(404).json({ error: 'Card not found' });
      return;
    }

    const now = new Date().toISOString();
    const updates: string[] = [];
    const values: any[] = [];

    if (data.front !== undefined) { updates.push('front = ?'); values.push(data.front); }
    if (data.back !== undefined) { updates.push('back = ?'); values.push(data.back); }
    if (data.hint !== undefined) { updates.push('hint = ?'); values.push(data.hint); }

    updates.push('updated_at = ?');
    values.push(now);
    values.push(req.params.id);

    await execute(`UPDATE cards SET ${updates.join(', ')} WHERE id = ?`, values);

    const updatedCard = await queryOne('SELECT * FROM cards WHERE id = ?', [req.params.id]);
    res.json({ card: updatedCard });
  } catch (error: any) {
    if (error.name === 'ZodError') {
      res.status(400).json({ error: error.errors[0].message });
      return;
    }
    console.error('Update card error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const card = await queryOne(
      `SELECT c.* FROM cards c JOIN decks d ON c.deck_id = d.id WHERE c.id = ? AND d.user_id = ?`,
      [req.params.id, req.user!.userId]
    );

    if (!card) {
      res.status(404).json({ error: 'Card not found' });
      return;
    }

    await execute('DELETE FROM cards WHERE id = ?', [req.params.id]);

    const countResult = await queryOne(
      'SELECT COUNT(*) as count FROM cards WHERE deck_id = ?',
      [card.deck_id as string]
    );

    const now = new Date().toISOString();
    await execute(
      'UPDATE decks SET card_count = ?, updated_at = ? WHERE id = ?',
      [countResult!.count, now, card.deck_id as string]
    );

    res.json({ message: 'Card deleted successfully' });
  } catch (error) {
    console.error('Delete card error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
