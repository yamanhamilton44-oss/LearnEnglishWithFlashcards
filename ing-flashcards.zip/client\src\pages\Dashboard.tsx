import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { decks as decksApi } from '../api/client';
import { DeckCard } from '../components/DeckCard';
import { CreateDeckModal } from '../components/CreateDeckModal';
import type { Deck } from '../types';

export function Dashboard() {
  const navigate = useNavigate();
  const [deckList, setDeckList] = useState<Deck[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const loadDecks = async () => {
    try {
      const response = await decksApi.list();
      setDeckList(response.decks);
    } catch {
      navigate('/login');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDecks();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      await decksApi.delete(id);
      setDeckList(prev => prev.filter(d => d.id !== id));
    } catch (err) {
      console.error('Failed to delete deck:', err);
    }
  };

  const handleCreate = () => {
    setShowCreateModal(false);
    loadDecks();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Your Decks</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            {deckList.length} {deckList.length === 1 ? 'deck' : 'decks'} total
          </p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-5 py-2.5 bg-primary-500 hover:bg-primary-600 text-white font-semibold rounded-xl transition-all active:scale-[0.98] shadow-lg shadow-primary-500/25"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
          </svg>
          New Deck
        </button>
      </div>

      {deckList.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 dark:bg-gray-800 rounded-2xl flex items-center justify-center">
            <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">No decks yet</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-6">Create your first flashcard deck to get started</p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-6 py-2.5 bg-primary-500 hover:bg-primary-600 text-white font-semibold rounded-xl transition-all"
          >
            Create your first deck
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {deckList.map(deck => (
            <DeckCard key={deck.id} deck={deck} onDelete={handleDelete} />
          ))}
        </div>
      )}

      {showCreateModal && (
        <CreateDeckModal
          onClose={() => setShowCreateModal(false)}
          onCreated={handleCreate}
        />
      )}
    </div>
  );
}
