import { getDatabase, persistDatabase } from '../database';

type Row = Record<string, any>;

export async function queryAll(sql: string, params: any[] = []): Promise<Row[]> {
  const db = await getDatabase();
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows: Row[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject() as Row);
  }
  stmt.free();
  return rows;
}

export async function queryOne(sql: string, params: any[] = []): Promise<Row | undefined> {
  const rows = await queryAll(sql, params);
  return rows[0];
}

export async function execute(sql: string, params: any[] = []): Promise<void> {
  const db = await getDatabase();
  db.run(sql, params);
  persistDatabase();
}

export async function executeTransaction(callback: () => void): Promise<void> {
  await execute('BEGIN TRANSACTION');
  try {
    callback();
    await execute('COMMIT');
  } catch (error) {
    await execute('ROLLBACK');
    throw error;
  }
}
